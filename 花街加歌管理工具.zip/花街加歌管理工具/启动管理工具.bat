@echo off
rem Huajie stage song manager launcher (keep this file ASCII-only: cmd misreads multi-byte text in .bat files)
cd /d "%~dp0"

where pythonw >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Please install it from https://www.python.org/downloads/
  echo During setup, tick "Add python.exe to PATH". Then double-click this file again.
  pause
  exit /b 1
)

start "" pythonw "%~dp0huajie_song_manager.pyw"
