"""花街 · 舞台演奏加歌管理工具

管理舞台演奏的曲库：添加新曲（MIDI）、设定每首是否公开显示、编辑已有曲目的信息（曲名、副标题、作曲 / 演唱、分类、介绍、
音色、疏密）、删除曲目，生成一个可以直接传到 GitHub 的压缩包。
压缩包里只有新增和改动的文件：
  _src/tools/stage-build/midi/<id>.mid    新曲子的 MIDI
  _src/tools/stage-build/songs.py         曲目表（新曲子加在同分类的最后；show=True 为公开，不写为隐藏）
  assets/bard/stage/songs.json            公开曲目的索引（星级按整个曲库重新排）
  assets/bard/stage/songs-all.json        全部曲目的索引（访客在选曲搜索框输对曲库密码后，由 Worker 发给他）
  assets/bard/stage/charts/<id>.json      新曲子的谱面（以及内容有变化的旧谱面）
删除只改曲目表和索引；删掉的曲子的 MIDI 和谱面文件要上传后在 GitHub 上手动删，工具会列出来。
GitHub 网页一次最多传 100 个文件：要传的超过 UPLOAD_LIMIT 个时，压缩包里分成「第1批」「第2批」……按顺序传
（谱面在前，曲目表和两个索引在最后一批，网站上不会先列出谱面还没到的曲子）。

谱面、星级都由仓库里现成的 build.py / chart.py 生成，规则和手动改曲库完全一样；生成后再跑一遍 check.py 体检。
曲库来源：默认从 GitHub 读最新提交（只下载要用的约 3 MB，不下整个仓库）；也可以选本机的网站文件夹。
需要 Python 3.9+ 和 mido、numpy（第一次打开会问要不要自动安装）。
"""
import concurrent.futures
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from tkinter.scrolledtext import ScrolledText
except ImportError:   # 只用下面的曲目表函数时（自测）不需要界面
    tk = None

OWNER, REPO, BRANCH = "djy998", "huajie-archive", "main"
STAGE = "_src/tools/stage-build"
ASSET = "assets/bard/stage"
TOOL_FILES = ["build.py", "chart.py", "check.py", "songs.py"]
INDEX_FILES = ["songs.json", "songs-all.json"]
HERE = Path(__file__).resolve().parent
CONFIG = HERE / "管理工具设置.json"
ID_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
DIFF_NAMES = ("仙人刺", "魔界花", "泰坦")
FALLBACK_INSTS = [("piano", "钢琴"), ("harp", "竖琴"), ("lute", "鲁特琴"), ("fiddle", "拨弦提琴"), ("violin", "小提琴"),
                  ("viola", "中提琴"), ("cello", "大提琴"), ("bass", "低音提琴"), ("flute", "长笛"), ("oboe", "双簧管"),
                  ("clarinet", "单簧管"), ("fife", "横笛"), ("panpipes", "排箫"), ("trumpet", "小号"), ("trombone", "长号"),
                  ("tuba", "大号"), ("horn", "圆号"), ("sax", "萨克斯")]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
UPLOAD_LIMIT = 95   # GitHub 网页一次最多传 100 个文件：超过这么多就在压缩包里分批（留一点余量）


# ==== 曲目表 songs.py：读、改 ====

def read_songs_py(path):
    """执行 songs.py，拿到 SONGS / TAGS / DEFAULT"""
    ns = {}
    exec(compile(Path(path).read_text(encoding="utf-8"), str(path), "exec"), ns)
    return ns["SONGS"], ns["TAGS"], ns.get("DEFAULT")


def py_str(s):
    return json.dumps(s, ensure_ascii=False)   # JSON 字符串也是合法的 Python 字符串字面量


def song_line(s):
    parts = [f"id={py_str(s['id'])}", f"t={py_str(s['t'])}", f"o={py_str(s.get('o', ''))}", f"c={py_str(s.get('c', ''))}",
             f"tag={py_str(s['tag'])}"]
    if s.get("inst"):
        parts.append(f"inst={py_str(s['inst'])}")
    if abs(float(s.get("gap", 1)) - 1) > 1e-9:
        parts.append(f"gap={float(s['gap']):g}")
    if s.get("note"):
        parts.append(f"note={py_str(s['note'])}")
    if s.get("show"):
        parts.append("show=True")
    return f"    dict({', '.join(parts)}),"


ONE_LINE = re.compile(r"^(?P<body>\s*dict\(.*\))\s*,\s*(?P<tail>#.*)?$")
SHOW_ARG = re.compile(r",\s*show\s*=\s*(?:True|False|1|0)")


def songs_block(lines):
    start = next(i for i, l in enumerate(lines) if l.startswith("SONGS = ["))
    end = next(i for i in range(start + 1, len(lines)) if lines[i].strip() == "]")
    return start, end


def song_span(lines, start, end, sid):
    """这一首在曲目表里占哪几行（一般一行一首；手写成多行的也认）"""
    pat = re.compile(r"\bid\s*=\s*[\"']%s[\"']" % re.escape(sid))
    for i in range(start + 1, end):
        if "dict(" in lines[i] and pat.search(lines[i]):
            j = i
            while not re.search(r"\)\s*,\s*(#.*)?$", lines[j]) and j + 1 < end:
                j += 1
            return i, j
    return None


def set_show(line, show):
    """一行一首：加上 / 去掉 show=True；认不出格式时返回 None（改用整行重写）"""
    m = ONE_LINE.match(line)
    if not m:
        return None
    body = SHOW_ARG.sub("", m.group("body"))
    if show:
        body = body[:-1] + ", show=True)"
    return body + "," + (f"  {m.group('tail')}" if m.group("tail") else "")


EDIT_KEYS = ("t", "o", "c", "tag", "note", "inst", "gap")   # 已有曲目能改的信息（id 是文件名，不能改）


def clean_edit(e):
    """编辑界面填的值 → 写进曲目表的值：字符串去首尾空白，gap 转成数，inst 空 = 按 MIDI 猜"""
    out = {}
    for k, v in (e or {}).items():
        if k not in EDIT_KEYS:
            continue
        out[k] = float(v) if k == "gap" else str(v).strip()
    return out


def insert_after_tag(lines, start, end, tag, line):
    """把一行加在同分类最后一首的后面（这个分类还没有曲子就加在列表末尾）；返回新的 end"""
    tag_pat = re.compile(r"\btag\s*=\s*%s" % re.escape(py_str(tag)))
    last = max((i for i in range(start, end) if tag_pat.search(lines[i])), default=None)
    if last is None:
        lines[end:end] = ["", f"    # ==== {tag} ====", line]
        return end + 3
    j = last   # 手写成多行的那一首：插在它的最后一行后面
    while not re.search(r"\)\s*,\s*(#.*)?$", lines[j]) and j + 1 < end:
        j += 1
    lines.insert(j + 1, line)
    return end + 1


def apply_plan(path, adds=(), shows=None, deletes=(), edits=None):
    """改曲目表：deletes 删掉、shows {id: 公开?} 改显示、edits {id: {曲名等: 新值}} 改信息、
    adds 加在同分类最后一首的后面（这个分类还没有曲子就加在列表末尾）。
    改了分类的曲子挪到新分类的最后（列表顺序就是选曲窗口里的顺序）。
    删掉的正好是 DEFAULT（第一次打开舞台时选中的）时，改成剩下的第一首。返回改好之后的 SONGS"""
    shows = dict(shows or {})
    deletes = set(deletes)
    edits = {sid: clean_edit(e) for sid, e in (edits or {}).items() if sid not in deletes}
    edits = {sid: e for sid, e in edits.items() if e}
    old_songs, _, default = read_songs_py(path)
    by_id = {s["id"]: s for s in old_songs}
    lines = Path(path).read_text(encoding="utf-8").split("\n")
    start, end = songs_block(lines)

    for sid in deletes:
        span = song_span(lines, start, end, sid)
        if not span:
            raise RuntimeError(f"曲目表里找不到 {sid}")
        del lines[span[0]:span[1] + 1]
        end -= span[1] - span[0] + 1
    for sid, show in shows.items():
        if sid in deletes or sid in edits:   # 也改了信息的，下面整行重写时一起改显示
            continue
        span = song_span(lines, start, end, sid)
        if not span:
            raise RuntimeError(f"曲目表里找不到 {sid}")
        new = set_show(lines[span[0]], show) if span[0] == span[1] else None
        if new is None:
            new = song_line({**by_id[sid], "show": show})
        lines[span[0]:span[1] + 1] = [new]
        end -= span[1] - span[0]
    for sid, e in edits.items():
        span = song_span(lines, start, end, sid)
        if not span:
            raise RuntimeError(f"曲目表里找不到 {sid}")
        old = by_id[sid]
        tail = re.search(r"\)\s*,\s*(#.*)$", lines[span[1]])   # 行尾注释保留
        new = song_line({**old, **e, "show": shows.get(sid, bool(old.get("show")))})
        if tail:
            new += f"  {tail.group(1)}"
        if e.get("tag", old["tag"]) != old["tag"]:
            del lines[span[0]:span[1] + 1]
            end -= span[1] - span[0] + 1
            end = insert_after_tag(lines, start, end, e["tag"], new)
        else:
            lines[span[0]:span[1] + 1] = [new]
            end -= span[1] - span[0]
    for s in adds:
        end = insert_after_tag(lines, start, end, s["tag"], song_line(s))

    if default in deletes:
        left = [s["id"] for s in old_songs if s["id"] not in deletes] + [s["id"] for s in adds]
        if not left:
            raise RuntimeError("曲目表不能删空")
        lines = [re.sub(r'^DEFAULT\s*=\s*"[^"]*"', f'DEFAULT = {py_str(left[0])}', l) for l in lines]

    Path(path).write_text("\n".join(lines), encoding="utf-8", newline="\n")
    songs, _, new_default = read_songs_py(path)
    got = {s["id"]: s for s in songs}
    want_ids = [s["id"] for s in old_songs if s["id"] not in deletes] + [s["id"] for s in adds]
    if set(got) != set(want_ids):
        raise RuntimeError("改曲目表出错了（曲目对不上），压缩包没生成")
    for sid, show in shows.items():
        if sid in got and bool(got[sid].get("show")) != bool(show):
            raise RuntimeError(f"改曲目表出错了（{sid} 的显示设置没改上），压缩包没生成")
    for sid, e in edits.items():
        for k, v in e.items():
            now = got[sid].get(k, 1.0 if k == "gap" else "")
            if (abs(float(now) - v) > 1e-9) if k == "gap" else (now != v):
                raise RuntimeError(f"改曲目表出错了（{sid} 的 {k} 没改上），压缩包没生成")
    if new_default not in got:
        raise RuntimeError("改曲目表出错了（DEFAULT 不在曲目表里），压缩包没生成")
    return songs


def slug(name):
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return re.sub(r"-{2,}", "-", s)


def fmt_dur(sec):
    sec = int(round(float(sec or 0)))
    return f"{sec // 60}:{sec % 60:02d}"


# ==== 曲库来源：把要用到的文件放进一个临时的「迷你仓库」 ====

def http_get(url, tries=3, timeout=30):
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "huajie-song-manager"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise FileNotFoundError(url)
            last = e
        except Exception as e:   # 网络抖一下就再试
            last = e
        time.sleep(1 + k)
    raise RuntimeError(f"下载失败：{url}（{last}）")


OLD_SITE = "曲库里没有 songs-all.json：网站还是旧版（不支持隐藏曲目），先把这次的网站更新传到 GitHub，再用本工具"


class Source:
    """root/ 下是迷你仓库（_src/tools/stage-build 与 assets/bard/stage），orig/ 是原样副本，用来比出哪些文件变了"""

    def __init__(self):
        self.work = Path(tempfile.mkdtemp(prefix="hj-songs-"))
        self.root = self.work / "repo"
        self.orig = self.work / "orig"
        self.label = ""
        self.sha = ""
        self.songs, self.tags, self.insts, self.default = [], [], FALLBACK_INSTS, ""
        self.index = {}
        self.mods = {}
        self.lock = threading.Lock()

    def cleanup(self):
        shutil.rmtree(self.work, ignore_errors=True)

    def _reset(self):
        with self.lock:
            self.mods = {}
        for d in (self.root, self.orig):
            shutil.rmtree(d, ignore_errors=True)
        (self.root / STAGE / "midi").mkdir(parents=True)
        (self.root / ASSET / "charts").mkdir(parents=True)

    def _finish(self, bard_js):
        self.songs, self.tags, self.default = read_songs_py(self.root / STAGE / "songs.py")
        index = json.loads((self.root / ASSET / "songs-all.json").read_text(encoding="utf-8"))
        self.index = {s["id"]: s for s in index.get("songs", [])}
        found = re.findall(r'id:\s*"([a-z]+)",\s*name:\s*"([^"]+)"', bard_js or "")
        self.insts = found or FALLBACK_INSTS
        shutil.copytree(self.root, self.orig)

    def latest_sha(self):
        data = json.loads(http_get(f"https://api.github.com/repos/{OWNER}/{REPO}/commits/{BRANCH}", timeout=20))
        return data["sha"], data["commit"]["committer"]["date"][:10], data["commit"]["message"].splitlines()[0]

    def load_github(self, log):
        sha, date, msg = self.latest_sha()
        log(f"GitHub 最新提交：{sha[:7]}（{date}）{msg}")
        self._reset()
        # 按提交号取文件：刚上传完马上再改曲库，也不会读到 CDN 里缓存的旧文件
        raw = lambda p: f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{sha}/{p}"
        for f in TOOL_FILES:
            (self.root / STAGE / f).write_bytes(http_get(raw(f"{STAGE}/{f}")))
        try:
            for f in INDEX_FILES:
                (self.root / ASSET / f).write_bytes(http_get(raw(f"{ASSET}/{f}")))
        except FileNotFoundError:
            raise RuntimeError(OLD_SITE)
        songs, _, _ = read_songs_py(self.root / STAGE / "songs.py")
        jobs = [(f"{STAGE}/midi/{s['id']}.mid", self.root / STAGE / "midi" / f"{s['id']}.mid") for s in songs]
        jobs += [(f"{ASSET}/charts/{s['id']}.json", self.root / ASSET / "charts" / f"{s['id']}.json") for s in songs]
        done = 0
        with concurrent.futures.ThreadPoolExecutor(8) as ex:
            futs = {ex.submit(http_get, raw(p)): dst for p, dst in jobs}
            for fu in concurrent.futures.as_completed(futs):
                try:
                    futs[fu].write_bytes(fu.result())
                except FileNotFoundError:   # 谱面还没生成过的，build.py 会补上
                    pass
                done += 1
                if done % 40 == 0 or done == len(jobs):
                    log(f"  已下载 {done}/{len(jobs)} 个文件")
        try:
            bard_js = http_get(raw("_src/bard.js")).decode("utf-8")
        except Exception:
            bard_js = ""
        self.sha = sha
        self.label = f"GitHub {BRANCH} @ {sha[:7]}（{date}）"
        self._finish(bard_js)

    def load_local(self, folder, log):
        folder = Path(folder)
        if not (folder / STAGE / "build.py").exists() or not (folder / ASSET / "songs.json").exists():
            raise RuntimeError("这个文件夹不像网站仓库：里面要有 _src/tools/stage-build/build.py 和 assets/bard/stage/songs.json")
        if not (folder / ASSET / "songs-all.json").exists():
            raise RuntimeError(OLD_SITE)
        self._reset()
        for f in TOOL_FILES:
            shutil.copy2(folder / STAGE / f, self.root / STAGE / f)
        for p in (folder / STAGE / "midi").glob("*.mid"):
            shutil.copy2(p, self.root / STAGE / "midi" / p.name)
        for f in INDEX_FILES:
            shutil.copy2(folder / ASSET / f, self.root / ASSET / f)
        for p in (folder / ASSET / "charts").glob("*.json"):
            shutil.copy2(p, self.root / ASSET / "charts" / p.name)
        bard = folder / "_src" / "bard.js"
        self.sha = ""
        self.label = f"本机文件夹 {folder}"
        self._finish(bard.read_text(encoding="utf-8") if bard.exists() else "")
        log(f"读取本机文件夹：{folder}")

    def tool_module(self, name):
        """从迷你仓库里导入 chart.py / build.py（用仓库里的规则分析 MIDI）"""
        import importlib
        with self.lock:   # 几首同时分析时只导入一次；重新读取曲库后清空重导
            if not self.mods:
                d = str(self.root / STAGE)
                if d not in sys.path:
                    sys.path.insert(0, d)
                os.environ["HJ_REPO"] = str(self.root)
                for m in ("songs", "chart", "build"):
                    sys.modules.pop(m, None)
                self.mods = {m: importlib.import_module(m) for m in ("chart", "build")}
            return self.mods[name]


FIELD_NAMES = {"t": "曲名", "o": "副标题", "c": "作曲 / 演唱", "tag": "分类", "note": "介绍", "inst": "音色", "gap": "疏密"}


def generate_package(src, adds, shows, deletes, out_dir, log, edits=None):
    """在迷你仓库里改曲目表、放 MIDI、跑 build.py 与 check.py，打包改动过的文件。
    返回 (压缩包路径, 要在 GitHub 上手动删的文件, 新的曲目表)"""
    edits = {sid: e for sid, e in (edits or {}).items() if e and sid not in deletes}
    shutil.rmtree(src.root)   # 每次都从原样副本重新开始，同一次打开里生成多次也不会叠加
    shutil.copytree(src.orig, src.root)
    stage = src.root / STAGE
    for it in adds:
        shutil.copy2(it["path"], stage / "midi" / f"{it['id']}.mid")
    for sid in deletes:
        (stage / "midi" / f"{sid}.mid").unlink(missing_ok=True)
    songs = apply_plan(stage / "songs.py", adds, shows, deletes, edits)
    if not any(s.get("show") for s in songs):
        raise RuntimeError("改完以后一首公开的曲子都没有了：访客打开舞台会没有曲子可选。至少留一首「显示」")
    names = {s["id"]: s["t"] for s in src.songs}
    if adds:
        log(f"新增 {len(adds)} 首：{'、'.join(s['t'] + ('（显示）' if s.get('show') else '（隐藏）') for s in adds)}")
    for show in (True, False):
        ids = [sid for sid, v in shows.items() if v is show and sid not in deletes]
        if ids:
            log(f"改为{'显示' if show else '隐藏'} {len(ids)} 首：{'、'.join(names.get(i, i) for i in ids)}")
    if edits:
        log(f"改信息 {len(edits)} 首：")
        for sid, e in edits.items():
            log(f"  {names.get(sid, sid)}：" + "；".join(f"{FIELD_NAMES.get(k, k)} → {v if v != '' else '（空）'}" for k, v in e.items()))
    if deletes:
        log(f"删除 {len(deletes)} 首：{'、'.join(names.get(i, i) for i in deletes)}")

    env = dict(os.environ, HJ_REPO=str(src.root), PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    py = sys.executable
    if py.lower().endswith("pythonw.exe") and Path(py[:-5] + ".exe").exists():
        py = py[:-5] + ".exe"
    touched = {s["id"] for s in adds} | set(edits)
    for script, what in (("build.py", "生成谱面、排星级"), ("check.py", "体检")):
        log(f"{what}（{script}）…")
        r = subprocess.run([py, script], cwd=stage, env=env, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        for l in out.splitlines():
            if any(i in l for i in touched) or "问题" in l or "✗" in l or l.startswith("!!") or "公开" in l:
                log("  " + l.strip())
        if r.returncode != 0:
            raise RuntimeError(f"{script} 没通过，压缩包没生成。完整输出：\n{out[-3000:]}")

    # 和原样副本比，只打包新增、改动的文件
    changed, removed = [], []
    for base in (STAGE, ASSET):
        for p in sorted((src.root / base).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                rel = p.relative_to(src.root).as_posix()
                o = src.orig / rel
                if not o.exists() or o.read_bytes() != p.read_bytes():
                    changed.append(rel)
        for p in sorted((src.orig / base).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and not (src.root / p.relative_to(src.orig)).exists():
                removed.append(p.relative_to(src.orig).as_posix())
    index = json.loads((src.root / ASSET / "songs-all.json").read_text(encoding="utf-8"))
    for e in index["songs"]:
        if e["id"] in touched and len(e.get("diffs") or []) == 3:
            log(f"  {e['t']}：" + " · ".join(f"{n} {d}星" for n, d in zip(DIFF_NAMES, e["diffs"])))
    name = f"花街曲库-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    dest = Path(out_dir) / name
    batches = upload_batches(changed)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for k, batch in enumerate(batches, 1):
            for rel in batch:
                z.write(src.root / rel, rel if len(batches) == 1 else f"第{k}批/{rel}")
    log(f"压缩包：{dest}（{len(changed)} 个文件" + (f"，分 {len(batches)} 批上传" if len(batches) > 1 else "") + "）")
    for k, batch in enumerate(batches, 1):
        if len(batches) > 1:
            log(f"  第{k}批（{len(batch)} 个文件）：")
        for rel in batch:
            log(f"    {rel}" if len(batches) > 1 else f"  {rel}")
    if removed:
        log("上传后要在 GitHub 上手动删掉这些文件（工具不会删）：")
        for rel in removed:
            log(f"  {rel}")
    return dest, removed, songs, len(batches)


def upload_batches(changed):
    """要上传的文件分批：不超过 UPLOAD_LIMIT 个时一批；超过时谱面在前，MIDI、曲目表在中间，两个索引在最后一批"""
    if len(changed) <= UPLOAD_LIMIT:
        return [list(changed)]
    index = [r for r in changed if r in (f"{ASSET}/{f}" for f in INDEX_FILES)]
    charts = [r for r in changed if r.startswith(f"{ASSET}/charts/")]
    rest = [r for r in changed if r not in index and r not in charts]
    order = charts + rest + index
    batches = [order[i:i + UPLOAD_LIMIT] for i in range(0, len(order), UPLOAD_LIMIT)]
    if len(batches) > 1 and not set(index) <= set(batches[-1]):   # 索引被拆开了：整组挪到单独的最后一批
        order = [r for r in order if r not in index]
        batches = [order[i:i + UPLOAD_LIMIT] for i in range(0, len(order), UPLOAD_LIMIT)] + [index]
    return batches


# ==== 界面 ====

class App:
    def __init__(self, root):
        self.root = root
        self.src = Source()
        self.items = []          # 新曲子：{path, id, t, o, c, tag, inst, gap, note, show, ok, info, guess}
        self.shows = {}          # 曲库里的：{id: 改成公开?}（和现在一样的不记）
        self.edits = {}          # 曲库里的：{id: {曲名等: 新值（字符串）}}（只记和现在不一样的）
        self.deletes = set()     # 曲库里要删的 id
        self.q = queue.Queue()
        self.busy = False
        self.loading = False
        self.stale = False       # 生成过压缩包、还没重新读取
        self.cfg = self.load_cfg()
        root.title("花街 · 舞台演奏加歌管理工具")
        scale = max(1.0, root.winfo_fpixels("1i") / 96)
        root.geometry(f"{int(1100 * scale)}x{int(900 * scale)}")
        root.minsize(int(900 * scale), int(720 * scale))
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.build_ui()
        root.after(100, self.poll)
        self.reload_source()

    # ---- 设置 ----
    def load_cfg(self):
        try:
            return json.loads(CONFIG.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def save_cfg(self):
        self.cfg.update(mode=self.mode.get(), local=self.local.get(), out=self.out.get())
        try:
            CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass

    def on_close(self):
        if self.pending_count() and not messagebox.askyesno("还有改动没生成", "有改动还没生成压缩包，关掉就没了。确定关闭？"):
            return
        self.save_cfg()
        self.src.cleanup()
        self.root.destroy()

    # ---- 布局 ----
    def build_ui(self):
        pad = dict(padx=8, pady=4)
        r = self.root
        r.columnconfigure(0, weight=1)
        r.rowconfigure(1, weight=4)
        r.rowconfigure(3, weight=1)

        box = ttk.LabelFrame(r, text="① 曲库来源（生成时以它为准）")
        box.grid(row=0, column=0, sticky="ew", **pad)
        box.columnconfigure(3, weight=1)
        self.mode = tk.StringVar(value=self.cfg.get("mode", "github"))
        self.local = tk.StringVar(value=self.cfg.get("local", ""))
        ttk.Radiobutton(box, text=f"GitHub 上的最新版（{OWNER}/{REPO}）", value="github", variable=self.mode,
                        command=self.reload_source).grid(row=0, column=0, columnspan=2, sticky="w", padx=6)
        ttk.Radiobutton(box, text="本机的网站文件夹：", value="local", variable=self.mode,
                        command=self.reload_source).grid(row=1, column=0, sticky="w", padx=6)
        ttk.Entry(box, textvariable=self.local).grid(row=1, column=1, columnspan=3, sticky="ew", padx=4)
        ttk.Button(box, text="选择…", command=self.pick_local).grid(row=1, column=4, padx=4)
        ttk.Button(box, text="重新读取", command=self.reload_source).grid(row=0, column=4, padx=4, pady=2)
        self.src_label = ttk.Label(box, text="正在读取…", foreground="#666")
        self.src_label.grid(row=2, column=0, columnspan=5, sticky="w", padx=6, pady=(0, 4))

        self.tabs = ttk.Notebook(r)
        self.tabs.grid(row=1, column=0, sticky="nsew", **pad)
        lib = ttk.Frame(self.tabs, padding=4)
        add = ttk.Frame(self.tabs, padding=4)
        self.tabs.add(lib, text="  ② 曲库里的曲子（显示 / 隐藏 / 改信息 / 删除）  ")
        self.tabs.add(add, text="  ③ 添加新曲  ")
        self.build_library(lib)
        self.build_adder(add)

        out = ttk.Frame(r)
        out.grid(row=2, column=0, sticky="ew", **pad)
        out.columnconfigure(1, weight=1)
        self.summary = ttk.Label(out, text="还没有改动", foreground="#666")
        self.summary.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))
        self.out = tk.StringVar(value=self.cfg.get("out") or str(Path.home() / "Desktop"))
        ttk.Label(out, text="④ 压缩包放到：").grid(row=1, column=0)
        ttk.Entry(out, textvariable=self.out).grid(row=1, column=1, sticky="ew", padx=4)
        ttk.Button(out, text="选择…", command=self.pick_out).grid(row=1, column=2, padx=4)
        self.go = ttk.Button(out, text="生成上传用压缩包", command=self.generate)
        self.go.grid(row=1, column=3, padx=(12, 0), ipadx=10, ipady=3)

        self.log_box = ScrolledText(r, height=9, font=("Consolas", 9), state="disabled", wrap="word")
        self.log_box.grid(row=3, column=0, sticky="nsew", **pad)

    def build_library(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        bar = ttk.Frame(f)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        self.view = tk.StringVar(value="all")
        for v, t in (("all", "全部"), ("show", "显示的"), ("hide", "隐藏的"), ("changed", "有改动的")):
            ttk.Radiobutton(bar, text=t, value=v, variable=self.view, command=self.fill_library).pack(side="left", padx=(4, 2))
        ttk.Label(bar, text="  搜索").pack(side="left")
        self.find = tk.StringVar()
        self.find.trace_add("write", lambda *a: self.fill_library())
        ttk.Entry(bar, textvariable=self.find, width=18).pack(side="left", padx=4)
        self.lib_count = ttk.Label(bar, text="", foreground="#666")
        self.lib_count.pack(side="left", padx=10)

        cols = ("state", "t", "id", "tag", "stars", "dur")
        self.lib = ttk.Treeview(f, columns=cols, show="headings", selectmode="extended")
        for c, w, txt in [("state", 130, "显示"), ("t", 230, "曲名"), ("id", 190, "id"), ("tag", 90, "分类"),
                          ("stars", 120, "星级（三档）"), ("dur", 60, "时长")]:
            self.lib.heading(c, text=txt)
            self.lib.column(c, width=w, stretch=(c in ("t", "id")))
        self.lib.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(f, orient="vertical", command=self.lib.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.lib.configure(yscrollcommand=sb.set)
        self.lib.tag_configure("show", foreground="#1b7a3a")
        self.lib.tag_configure("hide", foreground="#777")
        self.lib.tag_configure("changed", background="#fff4d6")
        self.lib.tag_configure("delete", foreground="#c33", background="#fde8e8")
        self.lib.tag_configure("edited", background="#e6f0ff")
        self.lib.bind("<Double-1>", lambda e: self.toggle_selected())
        self.lib.bind("<<TreeviewSelect>>", lambda e: self.show_lib_selected())

        btns = ttk.Frame(f)
        btns.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        ttk.Button(btns, text="设为显示", command=lambda: self.set_selected(True)).pack(side="left", padx=4)
        ttk.Button(btns, text="设为隐藏", command=lambda: self.set_selected(False)).pack(side="left", padx=4)
        ttk.Button(btns, text="删除选中…", command=self.delete_selected).pack(side="left", padx=(16, 4))
        ttk.Button(btns, text="撤销选中的改动", command=self.undo_selected).pack(side="left", padx=4)
        ttk.Label(btns, text="可以多选（Ctrl / Shift）；双击一行切换显示 / 隐藏。改动在生成压缩包时才生效",
                  foreground="#666").pack(side="left", padx=10)

        # 选中一首时，在这里改它的信息（id 是文件名，不能改）
        ed = ttk.LabelFrame(f, text="选中这首的信息（只选一首时可改；改过的行标蓝）")
        ed.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        for c in (1, 3):
            ed.columnconfigure(c, weight=1)
        self.lv = {k: tk.StringVar() for k in EDIT_KEYS}
        self.lib_widgets = []
        for key, label, row, col in [("t", "曲名", 0, 0), ("c", "作曲 / 演唱", 0, 2),
                                     ("o", "副标题（原名、出处）", 1, 0), ("note", "介绍（可空）", 1, 2)]:
            ttk.Label(ed, text=label).grid(row=row, column=col, sticky="e", padx=4, pady=2)
            e = ttk.Entry(ed, textvariable=self.lv[key])
            e.grid(row=row, column=col + 1, sticky="ew", padx=4, pady=2)
            self.lib_widgets.append(e)
        ttk.Label(ed, text="分类").grid(row=2, column=0, sticky="e", padx=4)
        self.lib_tag_box = ttk.Combobox(ed, textvariable=self.lv["tag"], state="readonly", width=14)
        self.lib_tag_box.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(ed, text="「跟随曲目」的音色").grid(row=2, column=2, sticky="e", padx=4)
        row2 = ttk.Frame(ed)
        row2.grid(row=2, column=3, sticky="w")
        self.lib_inst_box = ttk.Combobox(row2, state="readonly", width=24)
        self.lib_inst_box.pack(side="left", padx=4)
        self.lib_inst_box.bind("<<ComboboxSelected>>", lambda e: self.lib_inst_changed())
        ttk.Label(row2, text="疏密").pack(side="left", padx=(12, 2))
        lgap = ttk.Spinbox(row2, from_=0.5, to=2.0, increment=0.1, textvariable=self.lv["gap"], width=6)
        lgap.pack(side="left")
        ttk.Label(row2, text="（改音色、疏密会重新生成这首的谱面）", foreground="#666").pack(side="left", padx=4)
        self.lib_widgets += [self.lib_tag_box, self.lib_inst_box, lgap]
        for k, var in self.lv.items():
            if k != "inst":
                var.trace_add("write", lambda *a, k=k: self.lib_field_changed(k))
        self.lib_sid = None
        self.set_lib_editor_state(False)

    def build_adder(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        bar = ttk.Frame(f)
        bar.grid(row=0, column=0, sticky="ew", pady=2)
        ttk.Button(bar, text="添加 MIDI 文件…", command=self.add_files).pack(side="left", padx=4)
        ttk.Button(bar, text="移除选中", command=self.remove_selected).pack(side="left", padx=4)
        ttk.Label(bar, text="点一行，在下面改曲名、分类、是否显示；✗ 的不会加进去", foreground="#666").pack(side="left", padx=10)
        cols = ("file", "id", "t", "tag", "show", "inst", "state")
        lst = ttk.Frame(f)
        lst.grid(row=1, column=0, sticky="nsew")
        lst.columnconfigure(0, weight=1)
        lst.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(lst, columns=cols, show="headings", height=6, selectmode="extended")
        for c, w, txt in [("file", 150, "文件"), ("id", 140, "id"), ("t", 150, "曲名"), ("tag", 70, "分类"), ("show", 50, "显示"),
                          ("inst", 90, "音色"), ("state", 320, "情况")]:
            self.tree.heading(c, text=txt)
            self.tree.column(c, width=w, stretch=(c in ("t", "state")))
        self.tree.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(lst, orient="vertical", command=self.tree.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_selected())

        ed = ttk.LabelFrame(f, text="选中这首的信息")
        ed.grid(row=2, column=0, sticky="ew", pady=(6, 0))
        for c in (1, 3):
            ed.columnconfigure(c, weight=1)
        self.v = {k: tk.StringVar() for k in ("id", "t", "o", "c", "tag", "inst", "gap", "note")}
        self.v_show = tk.BooleanVar(value=False)
        fields = [
            ("id", "id（英文小写、数字、- ）", 0, 0), ("t", "曲名", 0, 2),
            ("o", "副标题（原名、出处）", 1, 0), ("c", "作曲 / 演唱", 1, 2),
            ("note", "介绍（可空）", 4, 0),
        ]
        self.widgets = []
        for key, label, row, col in fields:
            ttk.Label(ed, text=label).grid(row=row, column=col, sticky="e", padx=4, pady=2)
            e = ttk.Entry(ed, textvariable=self.v[key])
            e.grid(row=row, column=col + 1, sticky="ew", padx=4, pady=2, columnspan=(3 if key == "note" else 1))
            self.widgets.append(e)
        ttk.Label(ed, text="分类").grid(row=2, column=0, sticky="e", padx=4)
        self.tag_box = ttk.Combobox(ed, textvariable=self.v["tag"], state="readonly", width=14)
        self.tag_box.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(ed, text="「跟随曲目」的音色").grid(row=2, column=2, sticky="e", padx=4)
        inst_row = ttk.Frame(ed)
        inst_row.grid(row=2, column=3, sticky="w")
        self.inst_box = ttk.Combobox(inst_row, state="readonly", width=24)
        self.inst_box.pack(side="left", padx=4)
        self.inst_box.bind("<<ComboboxSelected>>", lambda e: self.inst_changed())
        ttk.Label(inst_row, text="疏密").pack(side="left", padx=(12, 2))
        gap = ttk.Spinbox(inst_row, from_=0.5, to=2.0, increment=0.1, textvariable=self.v["gap"], width=6)
        gap.pack(side="left")
        ttk.Label(inst_row, text="（1 为默认，>1 音更少）", foreground="#666").pack(side="left", padx=4)
        show = ttk.Checkbutton(ed, text="显示：所有人都能在选曲窗口看到（不勾 = 隐藏，在搜索框输入曲库密码按回车后才显示）",
                               variable=self.v_show, command=self.show_changed)
        show.grid(row=3, column=1, columnspan=3, sticky="w", padx=4, pady=2)
        self.widgets += [self.tag_box, self.inst_box, gap, show]
        for k, var in self.v.items():
            if k != "inst":
                var.trace_add("write", lambda *a, k=k: self.field_changed(k))
        self.set_editor_state(False)

    # ---- 日志与后台任务 ----
    def log(self, msg):
        self.q.put(("log", msg))

    def poll(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", payload + "\n")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
                elif kind == "call":
                    payload()
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def run_bg(self, fn, done=None, quiet=False):
        def work():
            try:
                res = fn()
                ok = True
            except Exception as e:
                res, ok = e, False
                if not quiet:   # 分析 MIDI 失败只在列表里标 ✗，不刷日志
                    self.log(f"出错了：{e}")
                    if not isinstance(e, RuntimeError):
                        self.log(traceback.format_exc())
            if done:
                self.q.put(("call", lambda: done(ok, res)))
        threading.Thread(target=work, daemon=True).start()

    # ---- 曲库来源 ----
    def pick_local(self):
        d = filedialog.askdirectory(title="选网站文件夹（里面有 _src 和 assets 的那个）", initialdir=self.local.get() or str(Path.home()))
        if d:
            self.local.set(d)
            self.mode.set("local")
            self.reload_source()

    def reload_source(self):
        if self.busy or self.loading:
            return
        self.loading = True
        self.save_cfg()
        self.src_label.configure(text="正在读取曲库…", foreground="#666")
        mode, local = self.mode.get(), self.local.get()

        def fn():
            if mode == "local":
                self.src.load_local(local, self.log)
            else:
                self.src.load_github(self.log)

        def done(ok, res):
            self.loading = False
            if ok:
                self.stale = False
                n_show = sum(1 for s in self.src.songs if s.get("show"))
                self.src_label.configure(text=f"已读取：{self.src.label}，现有 {len(self.src.songs)} 首（显示 {n_show}、隐藏 {len(self.src.songs) - n_show}）",
                                         foreground="#2a7")
                self.tag_box.configure(values=self.src.tags)
                self.lib_tag_box.configure(values=self.src.tags)
                ids = self.existing_ids()
                self.shows = {k: v for k, v in self.shows.items() if k in ids and v != self.orig_show(k)}
                self.deletes &= ids
                old_edits, self.edits = self.edits, {}
                for sid, e in old_edits.items():   # 重新读取后，和曲库里一样的项就不算改动了
                    if sid in ids:
                        for k, v in e.items():
                            self.set_edit(sid, k, v)
                self.lib_sid = None
                self.log(f"曲库读好了：{len(self.src.songs)} 首")
                self.fill_library()
                self.reanalyze_all()
            else:
                hint = "（GitHub 连不上的话，可以改用「本机的网站文件夹」）" if mode == "github" and str(res) != OLD_SITE else ""
                self.src_label.configure(text=f"读取失败：{res}{hint}", foreground="#c33")
        self.run_bg(fn, done)

    # ---- ② 曲库里的曲子 ----
    def existing_ids(self):
        return {s["id"] for s in self.src.songs}

    def orig_show(self, sid):
        return bool(next((s.get("show") for s in self.src.songs if s["id"] == sid), False))

    def now_show(self, sid):
        return self.shows.get(sid, self.orig_show(sid))

    def song_of(self, sid):
        return next((s for s in self.src.songs if s["id"] == sid), None)

    def orig_val(self, sid, k):
        """曲目表里现在的值，转成编辑框里的字符串（gap 没写 = 1）"""
        s = self.song_of(sid) or {}
        if k == "gap":
            return f"{float(s.get('gap', 1)):g}"
        return str(s.get(k, "") or "")

    def now_val(self, sid, k):
        return self.edits.get(sid, {}).get(k, self.orig_val(sid, k))

    def row_of(self, sid):
        s = self.song_of(sid)
        dele = sid in self.deletes
        on = self.now_show(sid)
        if dele:
            state = "✗ 将删除"
        elif sid in self.shows:
            state = f"{'显示' if self.orig_show(sid) else '隐藏'} → {'显示' if on else '隐藏'}"
        else:
            state = "显示" if on else "隐藏"
        if sid in self.edits and not dele:
            state += " · 改信息"
        e = self.src.index.get(sid, {})
        stars = "/".join(str(d) for d in (e.get("diffs") or [])) + " 星" if e.get("diffs") else ""
        tags = ("delete",) if dele else (("show" if on else "hide"),) + (("changed",) if sid in self.shows else ()) \
            + (("edited",) if sid in self.edits else ())
        return (state, self.now_val(sid, "t"), sid, self.now_val(sid, "tag"), stars, fmt_dur(e.get("dur"))), tags

    def fill_library(self):
        sel = set(self.lib.selection())
        self.lib.delete(*self.lib.get_children())
        q = self.find.get().strip().lower()
        view = self.view.get()
        shown = 0
        for s in self.src.songs:
            sid = s["id"]
            dele = sid in self.deletes
            changed = dele or sid in self.shows or sid in self.edits
            on = self.now_show(sid)
            if view == "show" and (not on or dele) or view == "hide" and (on or dele) or view == "changed" and not changed:
                continue
            if q and not any(q in str(s.get(k, "")).lower() or q in self.now_val(sid, k).lower() for k in ("t", "o", "c", "tag")) \
                    and q not in sid:
                continue
            values, tags = self.row_of(sid)
            self.lib.insert("", "end", iid=sid, values=values, tags=tags)
            shown += 1
        keep = [i for i in sel if self.lib.exists(i)]
        if keep:
            self.lib.selection_set(keep)
        n_show = sum(1 for s in self.src.songs if self.now_show(s["id"]) and s["id"] not in self.deletes)
        self.lib_count.configure(text=f"列出 {shown} 首 · 生成后：显示 {n_show}、隐藏 {len(self.src.songs) - len(self.deletes) - n_show}")
        self.update_summary()
        self.show_lib_selected()

    # ---- ② 改已有曲目的信息 ----
    def set_lib_editor_state(self, on):
        for w in self.lib_widgets:
            if isinstance(w, ttk.Combobox):
                w.configure(state="readonly" if on else "disabled")
            else:
                w.configure(state="normal" if on else "disabled")

    def show_lib_selected(self):
        ids = self.selected_ids()
        sid = ids[0] if len(ids) == 1 and ids[0] not in self.deletes else None
        if sid == self.lib_sid and sid is not None:
            return   # 同一首：不重填，免得打字时光标跳走
        self.lib_sid = sid
        self._loading_lib = True
        if sid is None:
            for var in self.lv.values():
                var.set("")
            self.lib_inst_box.set("")
            self.set_lib_editor_state(False)
        else:
            self.set_lib_editor_state(True)
            for k in EDIT_KEYS:
                if k != "inst":
                    self.lv[k].set(self.now_val(sid, k))
            used = self.src.index.get(sid, {}).get("inst", "")
            auto = f"自动（按 MIDI 猜：{self.inst_name(used)}）" if used and not self.orig_val(sid, "inst") else "自动（按 MIDI 猜）"
            self.lib_inst_values = [("", auto)] + list(self.src.insts)
            self.lib_inst_box.configure(values=[n for _, n in self.lib_inst_values])
            cur = self.now_val(sid, "inst")
            self.lib_inst_box.set(dict(self.lib_inst_values).get(cur, cur) if cur else auto)
        self._loading_lib = False

    def set_edit(self, sid, k, val):
        """记一项改动；改回原样就不记"""
        e = self.edits.setdefault(sid, {})
        same = val.strip() == self.orig_val(sid, k)
        if k == "gap":
            try:
                same = abs(float(val) - float(self.orig_val(sid, k))) < 1e-9
            except ValueError:
                same = False
        if same:
            e.pop(k, None)
        else:
            e[k] = val
        if not e:
            self.edits.pop(sid, None)
        if self.lib.exists(sid):
            values, tags = self.row_of(sid)
            self.lib.item(sid, values=values, tags=tags)
        self.update_summary()

    def lib_field_changed(self, k):
        if getattr(self, "_loading_lib", False) or not self.lib_sid:
            return
        self.set_edit(self.lib_sid, k, self.lv[k].get())

    def lib_inst_changed(self):
        if not self.lib_sid:
            return
        idx = self.lib_inst_box.current()
        self.set_edit(self.lib_sid, "inst", self.lib_inst_values[idx][0] if idx >= 0 else "")

    def selected_ids(self):
        return [i for i in self.lib.selection() if i in self.existing_ids()]

    def set_selected(self, show):
        ids = self.selected_ids()
        if not ids:
            messagebox.showinfo("先选曲子", "先在列表里点选要改的曲子（可以按住 Ctrl / Shift 多选）")
            return
        for sid in ids:
            self.deletes.discard(sid)
            if show == self.orig_show(sid):
                self.shows.pop(sid, None)
            else:
                self.shows[sid] = show
        self.fill_library()

    def toggle_selected(self):
        ids = self.selected_ids()
        if len(ids) == 1:
            self.set_selected(not self.now_show(ids[0]) or ids[0] in self.deletes)

    def delete_selected(self):
        ids = self.selected_ids()
        if not ids:
            messagebox.showinfo("先选曲子", "先在列表里点选要删的曲子（可以按住 Ctrl / Shift 多选）")
            return
        names = {s["id"]: s["t"] for s in self.src.songs}
        listing = "\n".join(f"· {names[i]}（{i}）" for i in ids[:15]) + (f"\n……共 {len(ids)} 首" if len(ids) > 15 else "")
        if not messagebox.askyesno("删除曲目", f"从曲目表里删掉这些曲子？\n\n{listing}\n\n"
                                   "生成压缩包时才生效。工具只改曲目表（songs.py 和两个索引），\n"
                                   "这些曲子的 MIDI 和谱面文件要你上传后在 GitHub 上手动删，生成时会列出来。"):
            return
        for sid in ids:
            self.deletes.add(sid)
            self.shows.pop(sid, None)
            self.edits.pop(sid, None)
        self.fill_library()

    def undo_selected(self):
        for sid in self.selected_ids():
            self.deletes.discard(sid)
            self.shows.pop(sid, None)
            self.edits.pop(sid, None)
        self.lib_sid = None   # 编辑区按原样重填
        self.fill_library()

    # ---- ③ 添加新曲 ----
    def unique_id(self, base, skip=None):
        taken = self.existing_ids() | {it["id"] for it in self.items if it is not skip}
        cand, n = base, 2
        while cand in taken:
            cand, n = f"{base}-{n}", n + 1
        return cand

    def add_files(self):
        paths = filedialog.askopenfilenames(title="选 MIDI 文件（可多选）", filetypes=[("MIDI 文件", "*.mid *.midi"), ("所有文件", "*.*")],
                                            initialdir=self.cfg.get("midi_dir") or str(Path.home()))
        if not paths:
            return
        self.cfg["midi_dir"] = str(Path(paths[0]).parent)
        default_tag = "其他" if "其他" in self.src.tags else (self.src.tags[-1] if self.src.tags else "")
        for p in paths:
            p = Path(p)
            if any(Path(it["path"]) == p for it in self.items):
                continue
            base = slug(p.stem) or "song-" + hashlib.md5(p.read_bytes()).hexdigest()[:6]
            it = dict(path=str(p), id="", t=p.stem, o="", c="", tag=default_tag, inst="", gap="1", note="", show=False,
                      ok=None, info="分析中…", guess="")
            it["id"] = self.unique_id(base, it)
            self.items.append(it)
            self.tree.insert("", "end", iid=str(id(it)), values=self.row_values(it))
            self.analyze(it)
        kids = self.tree.get_children()
        if kids and not self.tree.selection():
            self.tree.selection_set(kids[-1])
        self.update_summary()

    def remove_selected(self):
        for iid in self.tree.selection():
            self.items = [it for it in self.items if str(id(it)) != iid]
            self.tree.delete(iid)
        self.show_selected()
        self.update_summary()

    def inst_name(self, iid):
        return dict(self.src.insts).get(iid, iid)

    def row_values(self, it):
        inst = self.inst_name(it["inst"]) if it["inst"] else (f"自动（{self.inst_name(it['guess'])}）" if it["guess"] else "自动")
        mark = "✓ " if it["ok"] else ("✗ " if it["ok"] is False else "")
        return (Path(it["path"]).name, it["id"], it["t"], it["tag"], "显示" if it["show"] else "隐藏", inst, mark + it["info"])

    def refresh_row(self, it):
        iid = str(id(it))
        if self.tree.exists(iid):
            self.tree.item(iid, values=self.row_values(it))

    def reanalyze_all(self):
        for it in self.items:
            self.analyze(it)

    def analyze(self, it):
        """用仓库里的 chart.py 读一遍：读不了的 MIDI 当场标出来，读得了的显示时长、三档音数、猜的乐器"""
        if not self.src.songs:
            return
        path, gap = it["path"], it["gap"]

        def fn():
            chart = self.src.tool_module("chart")
            build = self.src.tool_module("build")
            notes, info = chart.read_notes(path)
            if not notes:
                raise RuntimeError("MIDI 里没有音符")
            try:
                g = float(gap)
            except ValueError:
                g = 1.0
            lvl, _ = chart.build_chart(notes, info, g)
            dur = max(n["end"] for n in notes) - notes[0]["t"]
            cnt = [sum(1 for l in lvl if l >= L) for L in (3, 2, 1)]
            return dur, cnt, build.guess_inst(info)

        def done(ok, res):
            if ok:
                dur, cnt, guess = res
                it["ok"], it["guess"] = True, guess
                it["info"] = f"{fmt_dur(dur)} · {'/'.join(DIFF_NAMES)} {cnt[0]}/{cnt[1]}/{cnt[2]} 个音"
                if cnt[0] < 40:
                    it["info"] += f"（{DIFF_NAMES[0]}档偏少）"
            else:
                it["ok"], it["info"] = False, f"读不了：{res}"
            self.refresh_row(it)
            if self.current() is it:
                self.show_selected()
        self.run_bg(fn, done, quiet=True)

    def current(self):
        sel = self.tree.selection()
        if len(sel) != 1:
            return None
        return next((it for it in self.items if str(id(it)) == sel[0]), None)

    def set_editor_state(self, on):
        for w in self.widgets:
            if isinstance(w, ttk.Combobox):
                w.configure(state="readonly" if on else "disabled")
            else:
                w.configure(state="normal" if on else "disabled")

    def show_selected(self):
        it = self.current()
        self._loading_fields = True
        if not it:
            for var in self.v.values():
                var.set("")
            self.v_show.set(False)
            self.inst_box.set("")
            self.set_editor_state(False)
        else:
            self.set_editor_state(True)
            for k in ("id", "t", "o", "c", "tag", "gap", "note"):
                self.v[k].set(it[k])
            self.v_show.set(bool(it["show"]))
            auto = f"自动（按 MIDI 猜：{self.inst_name(it['guess'])}）" if it["guess"] else "自动（按 MIDI 猜）"
            self.inst_values = [("", auto)] + list(self.src.insts)
            self.inst_box.configure(values=[n for _, n in self.inst_values])
            self.inst_box.set(next(n for i, n in self.inst_values if i == it["inst"]) if it["inst"] in dict(self.inst_values) else auto)
        self._loading_fields = False

    def inst_changed(self):
        it = self.current()
        if not it:
            return
        idx = self.inst_box.current()
        it["inst"] = self.inst_values[idx][0] if idx >= 0 else ""
        self.refresh_row(it)

    def show_changed(self):
        it = self.current()
        if it:
            it["show"] = bool(self.v_show.get())
            self.refresh_row(it)
            self.update_summary()

    def field_changed(self, key):
        if getattr(self, "_loading_fields", False):
            return
        it = self.current()
        if not it:
            return
        it[key] = self.v[key].get()
        self.refresh_row(it)
        if key == "gap":
            self.analyze(it)

    def pick_out(self):
        d = filedialog.askdirectory(title="压缩包放到哪", initialdir=self.out.get() or str(Path.home()))
        if d:
            self.out.set(d)
            self.save_cfg()

    # ---- 生成 ----
    def pending_count(self):
        return len([it for it in self.items if it["ok"] is not False]) + len(self.shows) + len(self.deletes) + len(self.edits)

    def update_summary(self):
        adds = [it for it in self.items if it["ok"] is not False]
        on = sum(1 for v in self.shows.values() if v)
        parts = [f"新增 {len(adds)} 首" if adds else "", f"改为显示 {on} 首" if on else "",
                 f"改为隐藏 {len(self.shows) - on} 首" if len(self.shows) - on else "",
                 f"改信息 {len(self.edits)} 首" if self.edits else "", f"删除 {len(self.deletes)} 首" if self.deletes else ""]
        text = "、".join(p for p in parts if p)
        stale = "（上次生成的压缩包上传后，点「重新读取」再改）" if self.stale else ""
        self.summary.configure(text=f"待生成：{text}{stale}" if text else f"还没有改动{stale}",
                               foreground="#b36b00" if text else "#666")

    def validate(self, items):
        errs = []
        ids = [it["id"] for it in items]
        for it in items:
            name = Path(it["path"]).name
            if not ID_RE.match(it["id"]):
                errs.append(f"{name}：id「{it['id']}」只能用英文小写字母、数字和 -，比如 my-song")
            if it["id"] in self.existing_ids():
                errs.append(f"{name}：id「{it['id']}」曲库里已经有了，换一个")
            if ids.count(it["id"]) > 1:
                errs.append(f"{name}：id「{it['id']}」和这次的另一首重复了")
            if not it["t"].strip():
                errs.append(f"{name}：曲名不能空")
            if it["tag"] not in self.src.tags:
                errs.append(f"{name}：分类没选")
            try:
                g = float(it["gap"])
                if not 0.3 <= g <= 3:
                    raise ValueError
            except ValueError:
                errs.append(f"{name}：疏密要是 0.3~3 之间的数")
        for sid, e in self.edits.items():
            if sid in self.deletes:
                continue
            name = f"{self.orig_val(sid, 't')}（{sid}）"
            if "t" in e and not e["t"].strip():
                errs.append(f"{name}：曲名不能空")
            if "tag" in e and e["tag"] not in self.src.tags:
                errs.append(f"{name}：分类没选")
            if "gap" in e:
                try:
                    g = float(e["gap"])
                    if not 0.3 <= g <= 3:
                        raise ValueError
                except ValueError:
                    errs.append(f"{name}：疏密要是 0.3~3 之间的数")
        public = [s for s in self.src.songs if s["id"] not in self.deletes and self.now_show(s["id"])]
        if not public and not any(it["show"] for it in items):
            errs.append("改完以后一首显示的曲子都没有了：访客打开舞台会没有曲子可选。至少留一首「显示」")
        return errs

    def generate(self):
        if self.busy or self.loading:
            return
        if not self.src.songs:
            messagebox.showwarning("还没读到曲库", "曲库来源还没读好，等一下或点「重新读取」")
            return
        if self.stale:
            messagebox.showinfo("先重新读取", "刚生成过压缩包。把它上传到 GitHub 后，点「重新读取」再接着改（不然这次的包会把上次的改动盖掉）")
            return
        if any(it["ok"] is None for it in self.items):
            messagebox.showinfo("稍等", "还有新曲子在分析，等列表里都出现 ✓ 或 ✗ 再生成")
            return
        items = [it for it in self.items if it["ok"]]
        if not items and not self.shows and not self.deletes and not self.edits:
            messagebox.showwarning("没有改动", "在「曲库里的曲子」里改显示 / 隐藏、改信息、删除，或在「添加新曲」里加 MIDI，再来生成")
            return
        errs = self.validate(items)
        if errs:
            messagebox.showwarning("还有几处要改", "\n".join(errs))
            return
        out_dir = Path(self.out.get())
        if not out_dir.is_dir():
            messagebox.showwarning("文件夹不存在", f"找不到 {out_dir}")
            return
        bad = [Path(it["path"]).name for it in self.items if it["ok"] is False]
        if bad and not messagebox.askyesno("有读不了的 MIDI", "这几个读不了，会跳过：\n" + "\n".join(bad) + "\n\n继续生成其余的？"):
            return
        self.save_cfg()
        self.busy = True
        self.go.configure(state="disabled", text="生成中…")
        mode = self.mode.get()
        adds = [dict(id=it["id"], t=it["t"].strip(), o=it["o"].strip(), c=it["c"].strip(), tag=it["tag"], inst=it["inst"],
                     gap=float(it["gap"]), note=it["note"].strip(), show=bool(it["show"]), path=it["path"]) for it in items]
        shows, deletes = dict(self.shows), set(self.deletes)
        edits = {sid: dict(e) for sid, e in self.edits.items() if sid not in deletes}
        start = lambda: self.run_bg(lambda: self.do_generate(adds, shows, deletes, out_dir, mode, edits), self.generated)
        last = self.cfg.get("last_gen") or {}
        if mode != "github" or not last.get("sha"):
            start()
            return

        # 上次生成的包是基于 GitHub 的某个提交；那之后 GitHub 没有新提交，说明上次的包多半还没上传，
        # 这次的包里不会有上次的改动，先后上传会把上次的盖掉
        def checked(ok, res):
            if ok and res[0] == last["sha"] and not messagebox.askyesno(
                    "上次的压缩包还没上传？",
                    f"上次生成的「{last.get('zip', '')}」（{last.get('what', '')}）之后，GitHub 上还没有新的提交，看起来还没上传。\n\n"
                    "这次生成的包里不会有上次的改动；如果两个包先后都传上去，上次的改动会被盖掉。\n"
                    "建议先上传上次的包，再回来点「生成」。\n\n"
                    "已经确定不要上次那个包了？点「是」继续生成。"):
                self.busy = False
                self.go.configure(state="normal", text="生成上传用压缩包")
                return
            start()
        self.run_bg(self.src.latest_sha, checked)

    def do_generate(self, adds, shows, deletes, out_dir, mode, edits=None):
        edits = edits or {}
        log = self.log
        log("—" * 30)
        # GitHub 上有新提交（比如刚上传过一批）就先重新读，免得新压缩包把上一批盖掉
        if mode == "github":
            sha, _, _ = self.src.latest_sha()
            if sha != self.src.sha:
                log("GitHub 上有新提交，重新读取曲库…")
                self.src.load_github(log)
                ids = self.existing_ids()
                clash = [s["id"] for s in adds if s["id"] in ids]
                if clash:
                    raise RuntimeError(f"这些 id 曲库里已经有了：{'、'.join(clash)}，改一下再生成")
                gone = [i for i in list(shows) + list(deletes) + list(edits) if i not in ids]
                if gone:
                    raise RuntimeError(f"这些曲子 GitHub 上的曲库里已经没有了：{'、'.join(gone)}，点「重新读取」后再改")
        return generate_package(self.src, adds, shows, deletes, out_dir, log, edits)

    def generated(self, ok, res):
        self.busy = False
        self.go.configure(state="normal", text="生成上传用压缩包")
        if not ok:
            messagebox.showerror("没生成成功", str(res)[:1500])
            return
        dest, removed, _, n_batch = res
        adds = [it for it in self.items if it["ok"]]
        what = "、".join(p for p in [f"新增 {len(adds)} 首" if adds else "", f"改显示 / 隐藏 {len(self.shows)} 首" if self.shows else "",
                                     f"改信息 {len(self.edits)} 首" if self.edits else "",
                                     f"删除 {len(self.deletes)} 首" if self.deletes else ""] if p)
        if self.mode.get() == "github" and self.src.sha:
            self.cfg["last_gen"] = {"sha": self.src.sha, "zip": dest.name, "what": what}
            self.save_cfg()
        for it in adds:
            self.tree.delete(str(id(it)))
            self.items.remove(it)
        self.shows, self.deletes, self.edits = {}, set(), {}
        self.lib_sid = None
        self.stale = True
        self.show_selected()
        self.fill_library()
        try:
            subprocess.run(["explorer", "/select,", str(dest)], creationflags=NO_WINDOW)
        except Exception:
            pass
        if n_batch > 1:
            msg = (f"已生成：{dest.name}（{what}）\n\n要传的文件超过 100 个（GitHub 网页一次最多 100 个），压缩包里分成了 {n_batch} 批。"
                   f"解压后按顺序：进入「第1批」文件夹，把里面的 _src / assets 文件夹拖进 GitHub 网页的上传页面（Add file → Upload files），"
                   f"提交；再传「第2批」……直到「第{n_batch}批」。不用改网站的版本号。")
        else:
            msg = (f"已生成：{dest.name}（{what}）\n\n解压后，把里面的 _src 和 assets 两个文件夹一起拖进 GitHub 网页的上传页面"
                   "（Add file → Upload files），提交即可。不用改网站的版本号。")
        if removed:
            shown = "\n".join(removed[:20]) + (f"\n……共 {len(removed)} 个（完整列表在下方日志里）" if len(removed) > 20 else "")
            msg += f"\n\n⚠ 还要在 GitHub 上手动删掉这些文件（删掉的曲子留下的，工具不会删）：\n{shown}"
        msg += "\n\n上传后点「重新读取」，就能接着改下一批。"
        messagebox.showinfo("好了", msg)


def main():
    try:   # 高分屏下字不发虚
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    if not have_deps() and not install_deps(root):
        root.destroy()
        return
    App(root)
    root.mainloop()


def have_deps():
    try:
        import mido, numpy  # noqa: F401
        return True
    except ImportError:
        return False


def install_deps(root):
    """第一次用：装 mido、numpy（pip，装到当前用户下），装的时候窗口里转着提示"""
    if not messagebox.askyesno("第一次使用", "需要先安装两个组件：mido（读 MIDI）和 numpy（算谱面），大约 20 MB。\n\n现在安装？"):
        return False
    py = sys.executable
    if py.lower().endswith("pythonw.exe") and Path(py[:-5] + ".exe").exists():
        py = py[:-5] + ".exe"
    root.title("花街 · 舞台演奏加歌管理工具")
    msg = ttk.Label(root, text="正在安装 mido 和 numpy，稍等……", padding=30)
    msg.pack()
    result = {}

    def work():
        r = subprocess.run([py, "-m", "pip", "install", "--user", "mido", "numpy"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        result["r"] = r

    th = threading.Thread(target=work, daemon=True)
    th.start()
    while th.is_alive():
        root.update()
        time.sleep(0.05)
    msg.destroy()
    import importlib
    import site
    importlib.invalidate_caches()
    try:   # 刚装到用户目录的包，这次运行里也能导入
        user_site = site.getusersitepackages()
        if user_site not in sys.path:
            sys.path.append(user_site)
    except Exception:
        pass
    if have_deps():
        return True
    r = result.get("r")
    messagebox.showerror("没装上", "安装没成功。可以在命令行运行：\npython -m pip install mido numpy\n\n" + ((r.stdout + r.stderr)[-1200:] if r else ""))
    return False


if __name__ == "__main__":
    main()
