"""花街 · 舞台演奏加歌小工具

选几个 MIDI 文件、填好曲名和分类，生成一个可以直接传到 GitHub 的压缩包：
  _src/tools/stage-build/midi/<id>.mid    新曲子的 MIDI
  _src/tools/stage-build/songs.py         曲目表（新曲子加在同分类的最后）
  assets/bard/stage/songs.json            曲目索引（星级会按整个曲库重新排）
  assets/bard/stage/charts/<id>.json      新曲子的谱面（以及内容有变化的旧谱面）

谱面、星级都由仓库里现成的 build.py / chart.py 生成，规则和手动加歌完全一样；生成后再跑一遍 check.py 体检。
曲库来源：默认从 GitHub 读最新提交（只下载要用的约 3 MB，不下整个仓库）；也可以选本机的网站文件夹。
需要 Python 3.9+ 和 mido、numpy（「启动加歌小工具.bat」会自动装）。
"""
import concurrent.futures
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import zipfile
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

OWNER, REPO, BRANCH = "djy998", "huajie-archive", "main"
STAGE = "_src/tools/stage-build"
ASSET = "assets/bard/stage"
TOOL_FILES = ["build.py", "chart.py", "check.py", "songs.py"]
HERE = Path(__file__).resolve().parent
CONFIG = HERE / "加歌小工具设置.json"
ID_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
FALLBACK_INSTS = [("piano", "钢琴"), ("harp", "竖琴"), ("lute", "鲁特琴"), ("fiddle", "拨弦提琴"), ("violin", "小提琴"),
                  ("viola", "中提琴"), ("cello", "大提琴"), ("bass", "低音提琴"), ("flute", "长笛"), ("oboe", "双簧管"),
                  ("clarinet", "单簧管"), ("fife", "横笛"), ("panpipes", "排箫"), ("trumpet", "小号"), ("trombone", "长号"),
                  ("tuba", "大号"), ("horn", "圆号"), ("sax", "萨克斯")]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ==== 曲库来源：把要用到的文件放进一个临时的「迷你仓库」 ====

def http_get(url, tries=3, timeout=30):
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "huajie-add-songs"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:   # 网络抖一下就再试
            last = e
            time.sleep(1 + k)
    raise RuntimeError(f"下载失败：{url}（{last}）")


def read_songs_py(path):
    """执行 songs.py，拿到 SONGS / TAGS / DEFAULT"""
    ns = {}
    exec(compile(Path(path).read_text(encoding="utf-8"), str(path), "exec"), ns)
    return ns["SONGS"], ns["TAGS"], ns.get("DEFAULT")


class Source:
    """root/ 下是迷你仓库（_src/tools/stage-build 与 assets/bard/stage），orig/ 是原样副本，用来比出哪些文件变了"""

    def __init__(self):
        self.work = Path(tempfile.mkdtemp(prefix="hj-add-songs-"))
        self.root = self.work / "repo"
        self.orig = self.work / "orig"
        self.label = ""
        self.sha = ""
        self.songs, self.tags, self.insts = [], [], FALLBACK_INSTS
        self.mods = {}
        self.lock = threading.Lock()

    def cleanup(self):
        shutil.rmtree(self.work, ignore_errors=True)

    def _reset(self):
        with self.lock:
            self.mods = {}
        for d in (self.root, self.orig):
            shutil.rmtree(d, ignore_errors=True)
        (self.root / STAGE / "midi").mkdir(parents=True)
        (self.root / ASSET / "charts").mkdir(parents=True)

    def _finish(self, bard_js):
        self.songs, self.tags, _ = read_songs_py(self.root / STAGE / "songs.py")
        found = re.findall(r'id:\s*"([a-z]+)",\s*name:\s*"([^"]+)"', bard_js or "")
        self.insts = found or FALLBACK_INSTS
        shutil.copytree(self.root, self.orig)

    def latest_sha(self):
        data = json.loads(http_get(f"https://api.github.com/repos/{OWNER}/{REPO}/commits/{BRANCH}", timeout=20))
        return data["sha"], data["commit"]["committer"]["date"][:10], data["commit"]["message"].splitlines()[0]

    def load_github(self, log):
        sha, date, msg = self.latest_sha()
        log(f"GitHub 最新提交：{sha[:7]}（{date}）{msg}")
        self._reset()
        # 按提交号取文件：刚上传完马上再加歌，也不会读到 CDN 里缓存的旧文件
        raw = lambda p: f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{sha}/{p}"
        for f in TOOL_FILES:
            (self.root / STAGE / f).write_bytes(http_get(raw(f"{STAGE}/{f}")))
        (self.root / ASSET / "songs.json").write_bytes(http_get(raw(f"{ASSET}/songs.json")))
        songs, _, _ = read_songs_py(self.root / STAGE / "songs.py")
        index = json.loads((self.root / ASSET / "songs.json").read_text(encoding="utf-8"))
        jobs = [(f"{STAGE}/midi/{s['id']}.mid", self.root / STAGE / "midi" / f"{s['id']}.mid") for s in songs]
        jobs += [(f"{ASSET}/charts/{s['id']}.json", self.root / ASSET / "charts" / f"{s['id']}.json") for s in index.get("songs", [])]
        done = 0
        with concurrent.futures.ThreadPoolExecutor(8) as ex:
            futs = {ex.submit(http_get, raw(p)): dst for p, dst in jobs}
            for fu in concurrent.futures.as_completed(futs):
                futs[fu].write_bytes(fu.result())
                done += 1
                if done % 40 == 0 or done == len(jobs):
                    log(f"  已下载 {done}/{len(jobs)} 个文件")
        try:
            bard_js = http_get(raw("_src/bard.js")).decode("utf-8")
        except Exception:
            bard_js = ""
        self.sha = sha
        self.label = f"GitHub {BRANCH} @ {sha[:7]}（{date}）"
        self._finish(bard_js)

    def load_local(self, folder, log):
        folder = Path(folder)
        if not (folder / STAGE / "build.py").exists() or not (folder / ASSET / "songs.json").exists():
            raise RuntimeError("这个文件夹不像网站仓库：里面要有 _src/tools/stage-build/build.py 和 assets/bard/stage/songs.json")
        self._reset()
        for f in TOOL_FILES:
            shutil.copy2(folder / STAGE / f, self.root / STAGE / f)
        for p in (folder / STAGE / "midi").glob("*.mid"):
            shutil.copy2(p, self.root / STAGE / "midi" / p.name)
        shutil.copy2(folder / ASSET / "songs.json", self.root / ASSET / "songs.json")
        for p in (folder / ASSET / "charts").glob("*.json"):
            shutil.copy2(p, self.root / ASSET / "charts" / p.name)
        bard = folder / "_src" / "bard.js"
        self.sha = ""
        self.label = f"本机文件夹 {folder}"
        self._finish(bard.read_text(encoding="utf-8") if bard.exists() else "")
        log(f"读取本机文件夹：{folder}")

    def tool_module(self, name):
        """从迷你仓库里导入 chart.py / build.py（用仓库里的规则分析 MIDI）"""
        import importlib
        with self.lock:   # 几首同时分析时只导入一次；重新读取曲库后清空重导
            if not self.mods:
                d = str(self.root / STAGE)
                if d not in sys.path:
                    sys.path.insert(0, d)
                os.environ["HJ_REPO"] = str(self.root)
                for m in ("songs", "chart", "build"):
                    sys.modules.pop(m, None)
                self.mods = {m: importlib.import_module(m) for m in ("chart", "build")}
            return self.mods[name]


# ==== 加进 songs.py ====

def py_str(s):
    return json.dumps(s, ensure_ascii=False)   # JSON 字符串也是合法的 Python 字符串字面量


def song_line(s):
    parts = [f"id={py_str(s['id'])}", f"t={py_str(s['t'])}", f"o={py_str(s['o'])}", f"c={py_str(s['c'])}", f"tag={py_str(s['tag'])}"]
    if s.get("inst"):
        parts.append(f"inst={py_str(s['inst'])}")
    if abs(float(s.get("gap", 1)) - 1) > 1e-9:
        parts.append(f"gap={float(s['gap']):g}")
    if s.get("note"):
        parts.append(f"note={py_str(s['note'])}")
    return f"    dict({', '.join(parts)}),"


def add_to_songs_py(path, new_songs):
    """每首加在同分类最后一首的后面（选曲窗口按列表顺序排）；这个分类还没有曲子就加在列表末尾"""
    lines = Path(path).read_text(encoding="utf-8").split("\n")
    start = next(i for i, l in enumerate(lines) if l.startswith("SONGS = ["))
    end = next(i for i in range(start + 1, len(lines)) if lines[i].strip() == "]")
    for s in new_songs:
        tag_pat = f"tag={py_str(s['tag'])}"
        last = max((i for i in range(start, end) if tag_pat in lines[i]), default=None)
        if last is None:
            lines[end:end] = ["", f"    # ==== {s['tag']} ====", song_line(s)]
            end += 3
        else:
            lines.insert(last + 1, song_line(s))
            end += 1
    Path(path).write_text("\n".join(lines), encoding="utf-8", newline="\n")


def slug(name):
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return re.sub(r"-{2,}", "-", s)


# ==== 界面 ====

class App:
    def __init__(self, root):
        self.root = root
        self.src = Source()
        self.items = []          # 每首：{path, id, t, o, c, tag, inst, gap, note, ok, info, guess}
        self.q = queue.Queue()
        self.busy = False
        self.loading = False
        self.cfg = self.load_cfg()
        root.title("花街 · 舞台演奏加歌小工具")
        scale = max(1.0, root.winfo_fpixels("1i") / 96)
        root.geometry(f"{int(1060 * scale)}x{int(780 * scale)}")
        root.minsize(int(860 * scale), int(620 * scale))
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.build_ui()
        root.after(100, self.poll)
        self.reload_source()

    # ---- 设置 ----
    def load_cfg(self):
        try:
            return json.loads(CONFIG.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def save_cfg(self):
        self.cfg.update(mode=self.mode.get(), local=self.local.get(), out=self.out.get())
        try:
            CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass

    def on_close(self):
        self.save_cfg()
        self.src.cleanup()
        self.root.destroy()

    # ---- 布局 ----
    def build_ui(self):
        pad = dict(padx=8, pady=4)
        r = self.root
        r.columnconfigure(0, weight=1)
        r.rowconfigure(1, weight=1)
        r.rowconfigure(4, weight=1)

        box = ttk.LabelFrame(r, text="① 曲库来源（生成时以它为准，新曲子加在它后面）")
        box.grid(row=0, column=0, sticky="ew", **pad)
        box.columnconfigure(3, weight=1)
        self.mode = tk.StringVar(value=self.cfg.get("mode", "github"))
        self.local = tk.StringVar(value=self.cfg.get("local", ""))
        ttk.Radiobutton(box, text=f"GitHub 上的最新版（{OWNER}/{REPO}）", value="github", variable=self.mode,
                        command=self.reload_source).grid(row=0, column=0, columnspan=2, sticky="w", padx=6)
        ttk.Radiobutton(box, text="本机的网站文件夹：", value="local", variable=self.mode,
                        command=self.reload_source).grid(row=1, column=0, sticky="w", padx=6)
        ttk.Entry(box, textvariable=self.local).grid(row=1, column=1, columnspan=3, sticky="ew", padx=4)
        ttk.Button(box, text="选择…", command=self.pick_local).grid(row=1, column=4, padx=4)
        ttk.Button(box, text="重新读取", command=self.reload_source).grid(row=0, column=4, padx=4, pady=2)
        self.src_label = ttk.Label(box, text="正在读取…", foreground="#666")
        self.src_label.grid(row=2, column=0, columnspan=5, sticky="w", padx=6, pady=(0, 4))

        mid = ttk.LabelFrame(r, text="② 要加的曲子（可以一次选多个 MIDI）")
        mid.grid(row=1, column=0, sticky="nsew", **pad)
        mid.columnconfigure(0, weight=1)
        mid.rowconfigure(1, weight=1)
        bar = ttk.Frame(mid)
        bar.grid(row=0, column=0, sticky="ew", pady=2)
        ttk.Button(bar, text="添加 MIDI 文件…", command=self.add_files).pack(side="left", padx=4)
        ttk.Button(bar, text="移除选中", command=self.remove_selected).pack(side="left", padx=4)
        ttk.Label(bar, text="点一行，在下面改曲名、分类等；✗ 的不会加进去", foreground="#666").pack(side="left", padx=10)
        cols = ("file", "id", "t", "tag", "inst", "state")
        self.tree = ttk.Treeview(mid, columns=cols, show="headings", height=7, selectmode="extended")
        for c, w, txt in [("file", 170, "文件"), ("id", 150, "id"), ("t", 170, "曲名"), ("tag", 80, "分类"), ("inst", 90, "音色"), ("state", 320, "情况")]:
            self.tree.heading(c, text=txt)
            self.tree.column(c, width=w, stretch=(c in ("t", "state")))
        self.tree.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_selected())

        ed = ttk.LabelFrame(r, text="③ 选中这首的信息")
        ed.grid(row=2, column=0, sticky="ew", **pad)
        for c in (1, 3):
            ed.columnconfigure(c, weight=1)
        self.v = {k: tk.StringVar() for k in ("id", "t", "o", "c", "tag", "inst", "gap", "note")}
        fields = [
            ("id", "id（英文小写、数字、- ）", 0, 0), ("t", "曲名", 0, 2),
            ("o", "副标题（原名、出处）", 1, 0), ("c", "作曲 / 演唱", 1, 2),
            ("note", "介绍（可空）", 3, 0),
        ]
        self.widgets = []
        for key, label, row, col in fields:
            ttk.Label(ed, text=label).grid(row=row, column=col, sticky="e", padx=4, pady=2)
            e = ttk.Entry(ed, textvariable=self.v[key])
            e.grid(row=row, column=col + 1, sticky="ew", padx=4, pady=2, columnspan=(3 if key == "note" else 1))
            self.widgets.append(e)
        ttk.Label(ed, text="分类").grid(row=2, column=0, sticky="e", padx=4)
        self.tag_box = ttk.Combobox(ed, textvariable=self.v["tag"], state="readonly", width=14)
        self.tag_box.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(ed, text="「跟随曲目」的音色").grid(row=2, column=2, sticky="e", padx=4)
        inst_row = ttk.Frame(ed)
        inst_row.grid(row=2, column=3, sticky="w")
        self.inst_box = ttk.Combobox(inst_row, state="readonly", width=24)
        self.inst_box.pack(side="left", padx=4)
        self.inst_box.bind("<<ComboboxSelected>>", lambda e: self.inst_changed())
        ttk.Label(inst_row, text="疏密").pack(side="left", padx=(12, 2))
        gap = ttk.Spinbox(inst_row, from_=0.5, to=2.0, increment=0.1, textvariable=self.v["gap"], width=6)
        gap.pack(side="left")
        ttk.Label(inst_row, text="（1 为默认，>1 音更少）", foreground="#666").pack(side="left", padx=4)
        self.widgets += [self.tag_box, self.inst_box, gap]
        for k, var in self.v.items():
            if k != "inst":
                var.trace_add("write", lambda *a, k=k: self.field_changed(k))
        self.set_editor_state(False)

        out = ttk.Frame(r)
        out.grid(row=3, column=0, sticky="ew", **pad)
        out.columnconfigure(1, weight=1)
        default_out = self.cfg.get("out") or str(Path.home() / "Desktop")
        self.out = tk.StringVar(value=default_out)
        ttk.Label(out, text="④ 压缩包放到：").grid(row=0, column=0)
        ttk.Entry(out, textvariable=self.out).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(out, text="选择…", command=self.pick_out).grid(row=0, column=2, padx=4)
        self.go = ttk.Button(out, text="生成上传用压缩包", command=self.generate)
        self.go.grid(row=0, column=3, padx=(12, 0), ipadx=10, ipady=3)

        self.log_box = ScrolledText(r, height=10, font=("Consolas", 9), state="disabled", wrap="word")
        self.log_box.grid(row=4, column=0, sticky="nsew", **pad)

    # ---- 日志与后台任务 ----
    def log(self, msg):
        self.q.put(("log", msg))

    def poll(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", payload + "\n")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
                elif kind == "call":
                    payload()
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def run_bg(self, fn, done=None, quiet=False):
        def work():
            try:
                res = fn()
                ok = True
            except Exception as e:
                res, ok = e, False
                if not quiet:   # 分析 MIDI 失败只在列表里标 ✗，不刷日志
                    self.log(f"出错了：{e}")
                    if not isinstance(e, RuntimeError):
                        self.log(traceback.format_exc())
            if done:
                self.q.put(("call", lambda: done(ok, res)))
        threading.Thread(target=work, daemon=True).start()

    # ---- 曲库来源 ----
    def pick_local(self):
        d = filedialog.askdirectory(title="选网站文件夹（里面有 _src 和 assets 的那个）", initialdir=self.local.get() or str(Path.home()))
        if d:
            self.local.set(d)
            self.mode.set("local")
            self.reload_source()

    def reload_source(self):
        if self.busy or self.loading:
            return
        self.loading = True
        self.save_cfg()
        self.src_label.configure(text="正在读取曲库…", foreground="#666")
        mode, local = self.mode.get(), self.local.get()

        def fn():
            if mode == "local":
                self.src.load_local(local, self.log)
            else:
                self.src.load_github(self.log)

        def done(ok, res):
            self.loading = False
            if ok:
                self.src_label.configure(text=f"已读取：{self.src.label}，现有 {len(self.src.songs)} 首，分类 {'、'.join(self.src.tags)}", foreground="#2a7")
                self.tag_box.configure(values=self.src.tags)
                self.log(f"曲库读好了：{len(self.src.songs)} 首")
                self.reanalyze_all()
            else:
                hint = "（GitHub 连不上的话，可以改用「本机的网站文件夹」）" if mode == "github" else ""
                self.src_label.configure(text=f"读取失败：{res}{hint}", foreground="#c33")
        self.run_bg(fn, done)

    # ---- 曲子列表 ----
    def existing_ids(self):
        return {s["id"] for s in self.src.songs}

    def unique_id(self, base, skip=None):
        taken = self.existing_ids() | {it["id"] for it in self.items if it is not skip}
        cand, n = base, 2
        while cand in taken:
            cand, n = f"{base}-{n}", n + 1
        return cand

    def add_files(self):
        paths = filedialog.askopenfilenames(title="选 MIDI 文件（可多选）", filetypes=[("MIDI 文件", "*.mid *.midi"), ("所有文件", "*.*")],
                                            initialdir=self.cfg.get("midi_dir") or str(Path.home()))
        if not paths:
            return
        self.cfg["midi_dir"] = str(Path(paths[0]).parent)
        default_tag = "其他" if "其他" in self.src.tags else (self.src.tags[-1] if self.src.tags else "")
        for p in paths:
            p = Path(p)
            if any(Path(it["path"]) == p for it in self.items):
                continue
            base = slug(p.stem) or "song-" + hashlib.md5(p.read_bytes()).hexdigest()[:6]
            it = dict(path=str(p), id="", t=p.stem, o="", c="", tag=default_tag, inst="", gap="1", note="", ok=None, info="分析中…", guess="")
            it["id"] = self.unique_id(base, it)
            self.items.append(it)
            self.tree.insert("", "end", iid=str(id(it)), values=self.row_values(it))
            self.analyze(it)
        kids = self.tree.get_children()
        if kids and not self.tree.selection():
            self.tree.selection_set(kids[-1])

    def remove_selected(self):
        for iid in self.tree.selection():
            self.items = [it for it in self.items if str(id(it)) != iid]
            self.tree.delete(iid)
        self.show_selected()

    def inst_name(self, iid):
        return dict(self.src.insts).get(iid, iid)

    def row_values(self, it):
        inst = self.inst_name(it["inst"]) if it["inst"] else (f"自动（{self.inst_name(it['guess'])}）" if it["guess"] else "自动")
        mark = "✓ " if it["ok"] else ("✗ " if it["ok"] is False else "")
        return (Path(it["path"]).name, it["id"], it["t"], it["tag"], inst, mark + it["info"])

    def refresh_row(self, it):
        iid = str(id(it))
        if self.tree.exists(iid):
            self.tree.item(iid, values=self.row_values(it))

    def reanalyze_all(self):
        for it in self.items:
            self.analyze(it)

    def analyze(self, it):
        """用仓库里的 chart.py 读一遍：读不了的 MIDI 当场标出来，读得了的显示时长、三档音数、猜的乐器"""
        if not self.src.songs:
            return
        path, gap = it["path"], it["gap"]

        def fn():
            chart = self.src.tool_module("chart")
            build = self.src.tool_module("build")
            notes, info = chart.read_notes(path)
            if not notes:
                raise RuntimeError("MIDI 里没有音符")
            try:
                g = float(gap)
            except ValueError:
                g = 1.0
            lvl, _ = chart.build_chart(notes, info, g)
            dur = max(n["end"] for n in notes) - notes[0]["t"]
            cnt = [sum(1 for l in lvl if l >= L) for L in (3, 2, 1)]
            return dur, cnt, build.guess_inst(info)

        def done(ok, res):
            if ok:
                dur, cnt, guess = res
                it["ok"], it["guess"] = True, guess
                it["info"] = f"{int(dur // 60)}:{int(dur % 60):02d} · 轻松/标准/挑战 {cnt[0]}/{cnt[1]}/{cnt[2]} 个音"
                if cnt[0] < 40:
                    it["info"] += "（轻松档偏少）"
            else:
                it["ok"], it["info"] = False, f"读不了：{res}"
            self.refresh_row(it)
            if self.current() is it:
                self.show_selected()
        self.run_bg(fn, done, quiet=True)

    # ---- 编辑选中的一首 ----
    def current(self):
        sel = self.tree.selection()
        if len(sel) != 1:
            return None
        return next((it for it in self.items if str(id(it)) == sel[0]), None)

    def set_editor_state(self, on):
        for w in self.widgets:
            if isinstance(w, ttk.Combobox):
                w.configure(state="readonly" if on else "disabled")
            else:
                w.configure(state="normal" if on else "disabled")

    def show_selected(self):
        it = self.current()
        self._loading_fields = True
        if not it:
            for var in self.v.values():
                var.set("")
            self.inst_box.set("")
            self.set_editor_state(False)
        else:
            self.set_editor_state(True)
            for k in ("id", "t", "o", "c", "tag", "gap", "note"):
                self.v[k].set(it[k])
            auto = f"自动（按 MIDI 猜：{self.inst_name(it['guess'])}）" if it["guess"] else "自动（按 MIDI 猜）"
            self.inst_values = [("", auto)] + list(self.src.insts)
            self.inst_box.configure(values=[n for _, n in self.inst_values])
            self.inst_box.set(next(n for i, n in self.inst_values if i == it["inst"]) if it["inst"] in dict(self.inst_values) else auto)
        self._loading_fields = False

    def inst_changed(self):
        it = self.current()
        if not it:
            return
        idx = self.inst_box.current()
        it["inst"] = self.inst_values[idx][0] if idx >= 0 else ""
        self.refresh_row(it)

    def field_changed(self, key):
        if getattr(self, "_loading_fields", False):
            return
        it = self.current()
        if not it:
            return
        it[key] = self.v[key].get()
        self.refresh_row(it)
        if key == "gap":
            self.analyze(it)

    def pick_out(self):
        d = filedialog.askdirectory(title="压缩包放到哪", initialdir=self.out.get() or str(Path.home()))
        if d:
            self.out.set(d)
            self.save_cfg()

    # ---- 生成 ----
    def validate(self, items):
        errs = []
        ids = [it["id"] for it in items]
        for it in items:
            name = Path(it["path"]).name
            if not ID_RE.match(it["id"]):
                errs.append(f"{name}：id「{it['id']}」只能用英文小写字母、数字和 -，比如 my-song")
            if it["id"] in self.existing_ids():
                errs.append(f"{name}：id「{it['id']}」曲库里已经有了，换一个")
            if ids.count(it["id"]) > 1:
                errs.append(f"{name}：id「{it['id']}」和这次的另一首重复了")
            if not it["t"].strip():
                errs.append(f"{name}：曲名不能空")
            if it["tag"] not in self.src.tags:
                errs.append(f"{name}：分类没选")
            try:
                g = float(it["gap"])
                if not 0.3 <= g <= 3:
                    raise ValueError
            except ValueError:
                errs.append(f"{name}：疏密要是 0.3~3 之间的数")
        return errs

    def generate(self):
        if self.busy or self.loading:
            return
        if not self.src.songs:
            messagebox.showwarning("还没读到曲库", "曲库来源还没读好，等一下或点「重新读取」")
            return
        pending = [it for it in self.items if it["ok"] is None]
        if pending:
            messagebox.showinfo("稍等", "还有曲子在分析，等列表里都出现 ✓ 或 ✗ 再生成")
            return
        items = [it for it in self.items if it["ok"]]
        if not items:
            messagebox.showwarning("没有可加的曲子", "先「添加 MIDI 文件」，列表里是 ✓ 的才会加进去")
            return
        errs = self.validate(items)
        if errs:
            messagebox.showwarning("还有几处要改", "\n".join(errs))
            return
        out_dir = Path(self.out.get())
        if not out_dir.is_dir():
            messagebox.showwarning("文件夹不存在", f"找不到 {out_dir}")
            return
        bad = [Path(it["path"]).name for it in self.items if it["ok"] is False]
        if bad and not messagebox.askyesno("有读不了的 MIDI", "这几个读不了，会跳过：\n" + "\n".join(bad) + "\n\n继续生成其余的？"):
            return
        self.save_cfg()
        self.busy = True
        self.go.configure(state="disabled", text="生成中…")
        mode = self.mode.get()
        snapshot = [dict(it) for it in items]
        start = lambda: self.run_bg(lambda: self.do_generate(snapshot, out_dir, mode), self.generated)
        last = self.cfg.get("last_gen") or {}
        if mode != "github" or not last.get("sha"):
            start()
            return

        # 上次生成的包是基于 GitHub 的某个提交；那之后 GitHub 没有新提交，说明上次的包多半还没上传，
        # 这次的包里不会有上次那几首，先后上传会把上次的盖掉
        def checked(ok, res):
            if ok and res[0] == last["sha"] and not messagebox.askyesno(
                    "上次的压缩包还没上传？",
                    f"上次生成的「{last.get('zip', '')}」（{last.get('titles', '')}）之后，GitHub 上还没有新的提交，看起来还没上传。\n\n"
                    "这次生成的包里不会有上次那几首；如果两个包先后都传上去，上次那几首会从曲目表里消失。\n"
                    "建议先上传上次的包，再回来点「生成」。\n\n"
                    "已经确定不要上次那个包了？点「是」继续生成。"):
                self.busy = False
                self.go.configure(state="normal", text="生成上传用压缩包")
                return
            start()
        self.run_bg(self.src.latest_sha, checked)

    def do_generate(self, items, out_dir, mode):
        log = self.log
        log("—" * 30)
        # GitHub 上有新提交（比如刚上传过一批）就先重新读，免得新压缩包把上一批盖掉
        if mode == "github":
            sha, _, _ = self.src.latest_sha()
            if sha != self.src.sha:
                log("GitHub 上有新提交，重新读取曲库…")
                self.src.load_github(log)
        taken = {s["id"] for s in self.src.songs}
        clash = [it["id"] for it in items if it["id"] in taken]
        if clash:
            raise RuntimeError(f"这些 id 曲库里已经有了：{'、'.join(clash)}，改一下再生成")
        # 每次都从原样副本重新开始，同一次打开里生成多次也不会叠加
        shutil.rmtree(self.src.root)
        shutil.copytree(self.src.orig, self.src.root)
        stage = self.src.root / STAGE
        for it in items:
            shutil.copy2(it["path"], stage / "midi" / f"{it['id']}.mid")
        songs = [dict(id=it["id"], t=it["t"].strip(), o=it["o"].strip(), c=it["c"].strip(), tag=it["tag"], inst=it["inst"],
                      gap=float(it["gap"]), note=it["note"].strip()) for it in items]
        add_to_songs_py(stage / "songs.py", songs)
        got, _, _ = read_songs_py(stage / "songs.py")
        if not {s["id"] for s in songs} <= {s["id"] for s in got}:
            raise RuntimeError("改 songs.py 出错了（新曲子没写进去）")
        log(f"songs.py 加了 {len(songs)} 首：{'、'.join(s['t'] for s in songs)}")

        env = dict(os.environ, HJ_REPO=str(self.src.root), PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        py = sys.executable
        if py.lower().endswith("pythonw.exe") and Path(py[:-5] + ".exe").exists():
            py = py[:-5] + ".exe"
        for script, what in (("build.py", "生成谱面"), ("check.py", "体检")):
            log(f"{what}（{script}）…")
            r = subprocess.run([py, script], cwd=stage, env=env, capture_output=True, text=True, encoding="utf-8",
                               errors="replace", creationflags=NO_WINDOW)
            out = (r.stdout or "") + (r.stderr or "")
            new_lines = [l for l in out.splitlines() if any(s["id"] in l for s in songs) or "问题" in l or "✗" in l or l.startswith("!!")]
            for l in new_lines:
                log("  " + l.strip())
            if r.returncode != 0:
                raise RuntimeError(f"{script} 没通过，压缩包没生成。完整输出：\n{out[-3000:]}")

        # 和原样副本比，只打包新增、改动的文件
        changed, removed = [], []
        for base in (STAGE, ASSET):
            for p in sorted((self.src.root / base).rglob("*")):
                if p.is_file() and "__pycache__" not in p.parts:
                    rel = p.relative_to(self.src.root).as_posix()
                    o = self.src.orig / rel
                    if not o.exists() or o.read_bytes() != p.read_bytes():
                        changed.append(rel)
            for p in sorted((self.src.orig / base).rglob("*")):
                if p.is_file() and "__pycache__" not in p.parts and not (self.src.root / p.relative_to(self.src.orig)).exists():
                    removed.append(p.relative_to(self.src.orig).as_posix())
        index = json.loads((self.src.root / ASSET / "songs.json").read_text(encoding="utf-8"))
        # 星级：新版曲库每档各一个（diffs = 轻松/标准/挑战），旧版只有 diff
        stars = {s["id"]: (s.get("diffs") or [s.get("diff", 0)]) for s in index["songs"]}
        for s in songs:
            d = stars.get(s["id"], [])
            log(f"  {s['t']}：" + ("轻松 {}星 · 标准 {}星 · 挑战 {}星".format(*d) if len(d) == 3 else "★" * (d[0] if d else 0)))
        name = f"花街加歌-{time.strftime('%Y%m%d-%H%M%S')}.zip"
        dest = out_dir / name
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in changed:
                z.write(self.src.root / rel, rel)
        log(f"压缩包：{dest}（{len(changed)} 个文件）")
        for rel in changed:
            log(f"  {rel}")
        if removed:
            log("注意：这些文件在新曲库里没有了，上传后要在 GitHub 上手动删掉：")
            for rel in removed:
                log(f"  {rel}")
        return dest, songs

    def generated(self, ok, res):
        self.busy = False
        self.go.configure(state="normal", text="生成上传用压缩包")
        if not ok:
            messagebox.showerror("没生成成功", str(res)[:1500])
            return
        dest, songs = res
        if self.mode.get() == "github" and self.src.sha:
            self.cfg["last_gen"] = {"sha": self.src.sha, "zip": dest.name, "titles": "、".join(s["t"] for s in songs)[:80]}
            self.save_cfg()
        done_ids = {s["id"] for s in songs}
        for it in [it for it in self.items if it["id"] in done_ids]:
            self.tree.delete(str(id(it)))
            self.items.remove(it)
        self.show_selected()
        try:
            subprocess.run(["explorer", "/select,", str(dest)], creationflags=NO_WINDOW)
        except Exception:
            pass
        messagebox.showinfo("好了", f"已生成：{dest.name}\n\n加了 {len(songs)} 首。解压后，把里面的 _src 和 assets 两个文件夹一起拖进 GitHub 网页的上传页面（Add file → Upload files），提交即可。\n\n不用改网站的版本号，访客下次打开舞台就能看到新曲子。")


def main():
    try:   # 高分屏下字不发虚
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    if not have_deps() and not install_deps(root):
        root.destroy()
        return
    App(root)
    root.mainloop()


def have_deps():
    try:
        import mido, numpy  # noqa: F401
        return True
    except ImportError:
        return False


def install_deps(root):
    """第一次用：装 mido、numpy（pip，装到当前用户下），装的时候窗口里转着提示"""
    if not messagebox.askyesno("第一次使用", "需要先安装两个组件：mido（读 MIDI）和 numpy（算谱面），大约 20 MB。\n\n现在安装？"):
        return False
    py = sys.executable
    if py.lower().endswith("pythonw.exe") and Path(py[:-5] + ".exe").exists():
        py = py[:-5] + ".exe"
    root.title("花街 · 舞台演奏加歌小工具")
    msg = ttk.Label(root, text="正在安装 mido 和 numpy，稍等……", padding=30)
    msg.pack()
    result = {}

    def work():
        r = subprocess.run([py, "-m", "pip", "install", "--user", "mido", "numpy"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        result["r"] = r

    th = threading.Thread(target=work, daemon=True)
    th.start()
    while th.is_alive():
        root.update()
        time.sleep(0.05)
    msg.destroy()
    import importlib
    import site
    importlib.invalidate_caches()
    try:   # 刚装到用户目录的包，这次运行里也能导入
        user_site = site.getusersitepackages()
        if user_site not in sys.path:
            sys.path.append(user_site)
    except Exception:
        pass
    if have_deps():
        return True
    r = result.get("r")
    messagebox.showerror("没装上", "安装没成功。可以在命令行运行：\npython -m pip install mido numpy\n\n" + ((r.stdout + r.stderr)[-1200:] if r else ""))
    return False


if __name__ == "__main__":
    main()
